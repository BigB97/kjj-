//go:build !rpctest
// +build !rpctest

package itest

var allTestCases = []*testCase{}
