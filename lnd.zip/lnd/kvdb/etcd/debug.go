//go:build dev
// +build dev

package etcd

const (
	// Switch on extra debug code.
	etcdDebug = true
)
