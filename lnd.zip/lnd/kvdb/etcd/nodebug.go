//go:build !dev
// +build !dev

package etcd

const (
	// Switch off extra debug code.
	etcdDebug = false
)
