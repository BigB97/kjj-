//go:build !dev
// +build !dev

package kvdb

const (
	// Switch off extra debug code.
	etcdDebug = false
)
