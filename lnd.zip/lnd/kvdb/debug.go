//go:build dev
// +build dev

package kvdb

const (
	// Switch on extra debug code.
	etcdDebug = true
)
